Actividad A8-Sound Meter
